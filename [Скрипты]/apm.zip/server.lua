--[[
// copyrights //
ACL Permissions Manager by SoRa
Notice : needs admin rights
// copyrights //
--]]

-- // Settings //
allowedGroup = "Admin"
-- // Settings //


addEvent("getACLs",true)
addEventHandler("getACLs",root,
    function ()
	acls = {}
	        for i,acl in ipairs(aclList()) do
            table.insert(acls,aclGetName ( acl ))
			end
               for i,v in ipairs(acls) do
			   triggerClientEvent(source,"addACLs",source,v)
			   end
	end
)


addEvent("getRights",true)
addEventHandler("getRights",root,
    function (acl)
	rights = {}
		for i,right in ipairs(aclListRights(aclGet(acl))) do
		table.insert(rights,right)
		end
		  for i,v in ipairs(rights) do
		  triggerClientEvent(source,"addRights",source,v)
	      end
	end
)

addEvent("reload_acl",true)
addEventHandler("reload_acl",root,
    function ()
	aclReload()
	outputChatBox("* APM : ACL Reloaded successfully",source,0,255,0,true)
	end
)


addEvent("set_a",true)
addEventHandler("set_a",root,
function (acl,right,access)
	if access ~= aclGetRight(aclGet(acl),right) then
	 aclSetRight (aclGet(acl),right,access)
	 aclSave()
	 outputChatBox("* APM : right "..right.." have been set to "..tostring(access).." in "..acl.." .",source,0,255,0,true)
	 else
	 outputChatBox("* APM : right "..right.." is already "..tostring(access).." .",source,0,255,0,true)
	 end
end
)



addEvent("remove_a",true)
addEventHandler("remove_a",root,
    function (acl,right)
	aclRemoveRight(aclGet(acl),right)
	outputChatBox("* APM : right "..right.." have been removed from "..acl.." .",source,0,255,0,true)
	end
)


addCommandHandler("apm",
function (player)
       if isObjectInACLGroup("user."..getAccountName(getPlayerAccount(player)),aclGetGroup(allowedGroup)) then
	   triggerClientEvent(player,"show_apm",player)
	   else
	  outputChatBox ( "ACL: Access denied for 'apm'", player, 255, 168, 0 )
       end
end)

